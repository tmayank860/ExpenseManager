package com.expensemanager.expensemanager.fragments;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.expensemanager.expensemanager.R;
import com.expensemanager.expensemanager.utils.IConstants;

public class AccountFragment extends Fragment {

    TextView textViewBudget;
    SharedPreferences sharedPreferences;

    float budget;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_account,
                container,
                false);

        sharedPreferences = getActivity().getSharedPreferences(IConstants.SP_NAME,
                Context.MODE_PRIVATE);

        budget = sharedPreferences.getFloat(IConstants.BUDGET, 0);

        textViewBudget = view.findViewById(R.id.textView_budget);

        textViewBudget.setText("Monthly Budget" + "\n" + String.valueOf(budget));

        return view;
    }
}
