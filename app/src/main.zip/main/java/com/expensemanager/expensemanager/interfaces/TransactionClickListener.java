package com.expensemanager.expensemanager.interfaces;

import com.expensemanager.expensemanager.models.TransactionModel;

public interface TransactionClickListener {

    void onTransactionClick(TransactionModel transactionModel);
}
